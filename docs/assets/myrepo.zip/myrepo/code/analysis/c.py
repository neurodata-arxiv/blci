import sys
import numpy as np

def read_mat(fn):
    return np.loadtxt(fn)

def read_modify_write(infn, val, outfn):
    mat = read_mat(infn)
    np.savetxt(outfn, val*mat, "%.3f")

if __name__ == "__main__":
    read_modify_write(sys.argv[1], float(sys.argv[2]), sys.argv[3])
