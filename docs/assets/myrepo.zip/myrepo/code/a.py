import sys
import numpy as np
from analysis.c import read_mat

if __name__ == "__main__":
    mat = read_mat("../otherdata/data.txt")
    np.savetxt("../data/databy2.txt", mat*2, "%.3f")
